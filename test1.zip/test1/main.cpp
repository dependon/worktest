
#include <QApplication>
#include <iostream>
#include "exam.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    std::string S1="qwe";
    std::vector<std::string> vector1=permutation2(S1);

    std::string S2="ad";
    std::vector<std::string> vector2=permutation2(S2);
    vector2.size();

    return a.exec();
}
