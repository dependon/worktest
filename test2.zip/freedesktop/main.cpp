#include <DApplication>
#include <DMainWindow>
#include <DWidgetUtil>
#include <QLocale>
#include <QSettings>
#include <QFile>
#include <QProcess>
#include <QDebug>

#include <DDesktopEntry>
#include <QFileInfo>
#include <iostream>
#include <vector>
DWIDGET_USE_NAMESPACE
DCORE_USE_NAMESPACE
using namespace std;

bool combineExecLine( const vector<string> & vecList, string& strExec )
{
    size_t count = 0;
    string strCombine;
    string::size_type pos, index = 0;

    while( -1 != (pos = strExec.find_first_of('%',index) ) ) {
         if( strExec.at(pos-1) != ' ' || !isalpha( strExec.at(pos+1) ) ) {
             cout << "Exec string format error!!" << endl;
             return false;
         }

         index = pos;
         if( count < vecList.size() ) {
            strExec.replace(pos,2, vecList[count]);
         }
         count ++;
    }

    if( count != vecList.size() ) {
        cout << "Input parameters count != Exec needs!!" << endl;
        return false;
    }

    return true;
}

int main(int argc, char *argv[])
{
    QString localPath;
    QVector <QString> vec;
    QMap <QString ,QString >map;
    for(int i = 1; i < argc; ++i)
    {
        if (strcmp(argv[i], "-d") == 0){
            if(i+1<argc){
                localPath=argv[i+1];
            }
        }
    }
    QFileInfo file(localPath);
    if(!file.exists()) return -1;
    if( file.suffix()!="desktop"){
        return 1;
    };
    DDesktopEntry desktop(localPath);  //指定需要解析的 desktop 文件名

    for(int i = 1; i < argc; ++i)
    {
        if (strcmp(argv[i], "-n") == 0){
            QString name =desktop.name();
            if(!name.isNull()){
                cout <<name.toStdString();
            }else {
                return -1;
            }
        }
        if (strcmp(argv[i], "-i") == 0){
            QString IconPath = desktop.stringValue("Icon");
            if(!IconPath.isNull()){
                cout <<IconPath.toStdString().c_str();
            }else {
                return -1;
            }

        }
        QString deepinVendor;
        if (strcmp(argv[i], "-e") == 0){
            if((i+1)<argc){
                int nPos = i+1;
                vector<string> vecList;
                FILE *fp;
                char buffer[1024];
                if(desktop.contains("Exec")){
                    deepinVendor = desktop.stringValue("Exec");
                }else {
                    return -1;
                }
                while(nPos<argc)
                {
                     //cout << "test" << nPos << "   " << argc <<endl;
                    string strFileName = argv[nPos];
                    vecList.push_back(strFileName);
                    nPos++;
                }
                string strExec = deepinVendor.toStdString();
                if(!combineExecLine(vecList,strExec))
                    return -1;

                if( NULL == (fp = popen( strExec.data(), "r") ) ) {
                    cout << "Exec <" << strExec.data() << "> failed!!" << endl;
                    return -1;
                }
                while( NULL != fgets(buffer, sizeof(buffer), fp) ) {
                    if( '\n' == buffer[strlen(buffer)-1] ) {
                        buffer[strlen(buffer)-1] = '\0';
                    }
                    cout << buffer << endl;
                }
            }else {
                return -1;
            }

        }
    }



    return 0;
}
